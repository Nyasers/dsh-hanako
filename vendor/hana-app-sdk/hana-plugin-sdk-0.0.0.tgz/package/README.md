# @hana/plugin-sdk

Browser-side SDK for Hana v2 App WebViews. New App UI should normally enter through manifest `contributes.cards[]` WebView cards; legacy page/widget WebView surfaces remain compatible. The native `chat.surface` and `hana.native` inline card forms are retired — the host downgrades newly produced cards of either shape to an unavailable placeholder and only keeps rendering pre-existing history. Neither ever rendered through this browser SDK; they were created server-side with the frozen v1 compatibility layer's own helpers. New App UI should use a WebView card instead.

This browser SDK does not expose `sampleText` or forward arbitrary server bus verbs. v2 Apps cannot call `model:sample-text` or `utility:call-text`; see [current limitations and compatibility boundaries](../../APPS_EN.md#current-limitations-and-compatibility-boundaries) for the distinction from installed v1 plugins and their host utility model configuration.

```ts
import { hana } from '@hana/plugin-sdk';

hana.ready();
const logoUrl = hana.assets.url('images/logo.svg');
hana.ui.resize({ height: 320 });
const runtime = hana.lifecycle.getSnapshot();
document.documentElement.dataset.hanaSurfaceActive = String(runtime.active);

await hana.toast.show({ message: 'Saved', type: 'success' });
await hana.external.open('https://example.com');
await hana.clipboard.writeText('Copied text');
await hana.resources.open({ resource: { kind: 'session-file', fileId: 'sf_1' }, mode: 'preview' });
```

`hana.ui.resize` applies to page, widget, and in-chat stream cards. Cards on the chalkboard keep user-owned geometry (drag and resize); resize reports do not apply there.

The host mints each in-stream app card's `a_*` instance id. Authors do not invent or overwrite it.

## Emit

`hana.emit(name, payload?, to?)` reports a completed user action into a conversation and starts an agent turn. It is card-slot only. The SDK stamps `userGesture` from `navigator.userActivation.isActive` (falling back to `event.isTrusted`); authors cannot self-report that bit. Delivery requires the host's existing `app/session.start-turn` grant. **Pass `to` only when the user asked to send it elsewhere.**

```ts
await hana.emit('item.selected', { id: 3 });
```

A successful call resolves `{ delivered: true, to? }`. `to` is echoed when the call carried it.

## Track

`hana.track(name, payload?)` writes a quiet activity record for the current card. It is card-slot only. It does not wake the agent, does not take `to` or `userGesture`, and writes an independent `app-card-activity/` store — not the Interactive Card `card-activity/` store. The write door requires a loaded v2 app and a host-minted card instance; it does not require the start-turn grant. The agent reads the log with `read_card_activity` using the `app-card:` entity id.

```ts
await hana.track('note', { key: 'C4' });
```

## Host-driven actions

The host can send `hana.ui.action` requests into a mounted card iframe (`describe_dom`, `click_element`, `type_text`, `read_state`). Authors do not declare this in `ui.hostCapabilities` and do not implement `hana.card-action`. The SDK answers those requests by default. Clicks do not call `focus()` and refuse `input[type=file]`. `describe_dom` never returns raw HTML. MCP cards are not driven.

## Assets

Use `hana.assets.url(path)` for files bundled under the App's `ui/` directory:

```ts
const js = hana.assets.url('dist/app.js');
const logo = hana.assets.url('/images/logo.svg');
```

The helper resolves `path` against the host-issued `hana-asset-base` iframe query parameter — the same static `ui/` tree the surface document itself was served from — so the returned URL carries whatever surface session the host attached to that base. It only works inside a surface the host opened; called outside one (the page was not opened with an asset base), it throws rather than guessing an unauthenticated URL. It accepts only relative, non-dotfile paths. The host asset route supports byte ranges for video playback, so Vite chunks, lazy imports, CSS, fonts, images, JSON, wasm, and browser-playable video files such as MP4 can all live under it. Starting with Hana 0.928.0, the host opens App UI under an authenticated path-scoped base. Ordinary relative entry scripts, CSS, nested module chunks and CSS resources inherit authorization without bootstrap code. Use relative build URLs; browser-root absolute URLs escape that base. On older hosts, entry resources still need the host-issued asset base and query credential, which does not automatically propagate to nested imports. Apps relying on normal relative loading should declare minAppVersion 0.928.0.

Because the URL `hana.assets.url()` returns carries a credential (the surface session), do not persist it or write it to logs — use it immediately, the same way you would a signed URL.

Do not put secrets, source files, or source maps under `ui/`. Agent-generated apps and newly edited app UI should not create custom route handlers just to serve static files such as CSS, JS, images, or MP4; treat `hana.assets.url(...)` as the documented contract for new work.

## App API Routes

Use `hana.api.fetch(path, init)` when browser code calls this app's own route handlers:

```ts
const res = await hana.api.fetch('api/translate', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ domain: 'football' }),
});
```

The helper builds `/api/apps/{appId}/routes/{path}` for the current WebView app and sends the `X-Hana-App-Surface-Session` header from the WebView URL. Do not reuse the `appIframeTicket` document-load ticket for `fetch()` calls, and do not hard-code `/api/apps/{appId}/...` in browser code. `hana.api.url(path)` is available when you only need the current app route URL. For managed service paths (`/_runtime/<runtimeId>/entry-path`), it returns a path-authenticated URL suitable for relative scripts, module imports and WebSockets, including desktop `file://` hosts where third-party cookies are unavailable. Do not persist or log these credential-bearing URLs.

## Host Requests

Stable helpers are thin wrappers around `hana.host.request(type, payload)`.

| Helper | Capability | Grant | Ledger word (v2 apps) | Slots |
| --- | --- | --- | --- | --- |
| `hana.emit(name, payload?, to?)` | `hana.emit` | start-turn on the server | `app/session.start-turn` | card |
| `hana.track(name, payload?)` | `hana.track` | loaded app + card instance | n/a | card |
| `hana.toast.show(input)` | `toast.show` | no | n/a | page, widget, card, settings |
| `hana.external.open(input)` | `external.open` | yes | `app/ui.open-external` | page, widget, settings |
| `hana.clipboard.writeText(input)` | `clipboard.writeText` | yes | `app/ui.clipboard-write` | page, widget, settings |
| `hana.resources.open(input)` | `resource.open` | yes | `app/resources.read` | page, widget, card, settings |
| `hana.resources.pick(input)` | `resource.pick` | yes | `app/resources.read` | page, widget, card, settings |
| `hana.resources.requestAccess(input)` | `resource.requestAccess` | yes | `app/resources.read` | page, widget, card, settings |

For a v2 app (`manifestVersion: 2`), a grant-required capability is not
declared per card — it rides the app's own permission-ledger word, listed in
the top-level `manifest.json` `capabilities` array alongside every other
capability the app wants (`app/tools.expose-to-model`,
`app/resources.read`, and so on):

```json
{
  "manifestVersion": 2,
  "capabilities": ["app/ui.open-external", "app/ui.clipboard-write", "app/resources.read"]
}
```

The user confirms the app's declared capabilities once, at install; each word
can be granted or revoked afterwards from the Security settings page's App
capabilities panel, or the app's own Extensions detail page — the same place
every other `app/*` capability is managed. `resource.open`, `resource.pick`,
and `resource.requestAccess` all ride the same `app/resources.read` word;
there is no separate write-side iframe capability. `contributes.cards[]` has
no `hostCapabilities` field of its own — a card contribution that writes one
is rejected as an unknown key; the grant is App-wide, not per card. (A v1
manifest, `manifestVersion: 1`, instead declared these as
`ui.hostCapabilities`; that compatibility runtime remains frozen.)

Slot availability is part of the host contract. Holding the grant does not
make that capability valid in every WebView slot: Chalkboard card slots may
show toasts and resource prompts, but direct clipboard writes and external
opens are denied so small embedded cards cannot surprise the user with
global side effects. Use a page/widget/settings surface, or route the
workflow through an explicit Chalkboard/App-card action, when it needs those
actions.

Browser-side resource helpers are host requests only. They can ask Hana to open
or reveal local/session/url resources, show the host picker, or request access,
but they do not expose direct filesystem read or write APIs inside the WebView.
Runtime code that actually reads or edits user resources should use the
server-side `ctx.resources` a tool or app receives, not this browser SDK.

Do not mirror runtime ResourceIO operations into WebView code. The browser SDK is
for presentation and host-mediated actions; server-side App tools, routes, or
lifecycle code own the actual resource read/write path.

## Surface Lifecycle And Frame Budget

Use `hana.lifecycle.getSnapshot()` for the current WebView runtime budget and
`hana.lifecycle.subscribe(callback)` for host updates. Foreground surfaces
default to `maxFrameRate: 60`. Hidden or inactive surfaces receive
`active: false`, `maxFrameRate: 0`, and `motion: "paused"`.

Use `hana.performance.requestAnimationFrame(callback)` for App-owned canvas,
WebGL, ticker, or DOM animation loops that should follow the host budget:

```ts
let frame = hana.performance.requestAnimationFrame(function draw(time) {
  renderFrame(time);
  frame = hana.performance.requestAnimationFrame(draw);
});

const unsubscribe = hana.lifecycle.subscribe((snapshot) => {
  document.documentElement.dataset.hanaSurfaceActive = String(snapshot.active);
});

// Later:
hana.performance.cancelAnimationFrame(frame);
unsubscribe();
```

The performance helper does not replace browser globals. If an App uses raw
`requestAnimationFrame`, CSS infinite animations, or autoplaying video, it
should subscribe to `hana.lifecycle` and pause or reduce those effects when the
surface is inactive.

## Theme

A v2 App's colours come from the theme the user picked in settings. Following it is
the default: the SDK keeps the surface on the current theme, and an App that does
nothing at all still changes with it. No reload is involved, so plugin state survives
a theme switch.

The host puts the theme in force on the iframe URL as `hana-theme` and `hana-css`
(alongside `hana-asset-base`), which is what dresses the surface on first paint. Every
change after that arrives as a message, and the SDK fetches that theme's stylesheet and
swaps it in once the text is in hand, so the surface is never left unstyled mid-swap.

`hana.theme.getSnapshot()` and `hana.theme.subscribe(callback)` report what is in force.
A snapshot carries the theme id and the stylesheet address for it. There are no colour
values in the message: the stylesheet the plugin already links is the same one the host
uses, so nothing is translated on the way over and no colour can exist on the plugin
side that the user's theme does not define.

Newer hosts may also include `appearance: 'light' | 'dark'` and a `palettes` pair. Each
palette carries a host-issued `{ theme, cssUrl }`: the current face keeps the user's named
theme, while the opposite face is the host registry's default for that appearance. These
URLs are optional metadata for surfaces that must render both faces; consume the supplied
URLs and never manufacture another theme URL. Older hosts keep returning only `theme` and
`cssUrl`.

```js
import { hana } from "@hana/plugin-sdk";

// Only needed to react to a change — the repaint happens without this.
hana.theme.subscribe(({ theme }) => {
  redrawCanvasLabels(theme);
});
```

Reading a colour in JavaScript (for canvas work, say) means reading it off the document,
where the stylesheet has already put it:

```js
const ink = getComputedStyle(document.documentElement).getPropertyValue("--text");
```

Two options on `createHanaPluginSdk`: `followHostTheme: false` for a surface that must
keep one fixed palette, and `onThemeError` to hear about a stylesheet that would not
load. A failed swap keeps the current theme rather than falling back to a built-in
palette — an App should never end up wearing colours the user never chose.

## Size envelope

The host tells an App page the size constraint of the mount it is sitting in.
`hana.envelope.getSnapshot()` returns that constraint, or `null` if no signal has
arrived yet (older hosts never send one). `hana.envelope.subscribe(callback)` follows
the same snapshot-and-subscribe shape as `hana.theme`. Each axis is independently
`fixed` (host-locked `value`), `flexible` (content-sized with `max`), or `unbounded`
(no number). A page that does not read this API is unchanged.

## App document views

`hana.document.onViewRequest(handler)` handles requests from this App's own registered, authorized model tools. It is separate from save/undo lifecycle requests. The handler receives `HanaDocumentViewRequest` and returns `HanaDocumentViewResult`: one revision, App-defined JSON data, and optional PNG/JPEG/WebP base64 images from that same view. Unregister on teardown and reject stale observations explicitly.

Associate server tools with `view: { providerId }` and use the host-issued document access with `ctx.documents.requestView`; the host supplies exact view routing without implementing the App's professional commands. See [App-owned view tools](../../APPS_EN.md#app-owned-view-tools) for the complete contract, limits, and image content example.

## Author validation

The Hana author toolchain provides `node scripts/validate-app.mjs --dir <app> --json` and `--archive <install.zip>`. It reuses host manifest/image rules, checks packaged resource paths and exits nonzero on errors. Run `--smoke` explicitly for temporary AppHost and authenticated browser startup validation. The Creator skill requires these checks before delivery; static validation alone does not prove runtime behavior. These developer commands run from a Hana checkout and do not add validation/image-decoding dependencies to this browser SDK. A relocated Creator skill can select the checkout with `HANA_APP_TOOLS_ROOT`.

The distributed SDK tarball also contains `dist/browser.js`, a self-contained ES module for plain HTML Apps. The Creator multi-file UI scaffold copies it into its own `ui/assets/sdk.js`; no CDN or host node_modules access is required.

Preview view closure belongs to the host and never waits for an App response. Closing or replacing a view releases its binding; it does not save or discard App documents. Persist recoverable drafts before acknowledging edits and treat save as a separate command. The existing `prepareClose` message remains compatible but is not a host close veto. App API responses may contain the host `{ error, code }` envelope on a non-success HTTP status; check the response status and preserve that reason.

### App surface identity

Hana 0.939.0 adds `hana.surface.getContext()` and
`hana.surface.onContextChanged(listener)` for authenticated App cards,
Function Panels and custom settings pages. The snapshot is `null` before the
host handshake, then `{ appId, slot, cardInstanceId }`. A card and its
associated Function Panel share the host-stamped card instance ID; a settings
page has no card instance ID. Treat this as association metadata, never as an
access credential. Subscribe before acting on it and unsubscribe on disposal.

Declare a panel document with `contributes.cards[].functionPanel.route` and a
settings document with `contributes.settings.ui.route`, both inside the App's
`ui/` tree. The panel accompanies its card when detached. These App surfaces
receive theme, lifecycle, size envelopes and App storage change notifications.
Function Panels and settings pages do not receive main-card state or action
execution authority, and have no implicit current agent. Use explicit storage
keys or the App backend to synchronize state between documents; separate
iframes do not share JavaScript contexts. Loopback embeds retain their existing
semantics and do not gain these capabilities.

### Opening an App-owned card

From Hana 0.940.0, `await hana.cards.open('settings')` opens or reveals a card
listed in the calling App's manifest. It returns
`{ cardInstanceId, existing, detached }`; an existing detached instance is
raised instead of duplicated. This is available after the authenticated
handshake in App cards, Function Panels and custom settings pages. It accepts
no App identity or arbitrary card instance ID. Missing cards, unready callers
and unavailable detached-window focus are explicit errors.
