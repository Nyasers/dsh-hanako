# @hana/plugin-components

React component primitives for Hana v2 App WebViews. The root entry provides the existing card-oriented primitives. `@hana/plugin-components/settings` is the supported entry for Hana/App settings and management pages; it bundles the current host settings primitives and their styles into the App package.

For a v2 App card, declare a required `face.image` in `contributes.cards[]` and bundle a nonempty PNG/WebP/SVG under the App's `ui/` directory. React card components do not replace this manifest cover. Use `AppManifestCardContributionV2` from `@hana/app-sdk` for the author-facing declaration; development checks and new or replacement installations require a valid path and file. Runtime loading remains compatible with installed legacy Apps without covers; unusable declared cover files are omitted with a warning.

This package is for browser-rendered v2 App WebView UI. It does not expose the host's internal React modules or native descriptor rendering APIs.

```tsx
import {
  Button,
  SaveButton,
  SettingRow,
  SettingsPage,
  SettingsSection,
  Switch,
} from '@hana/plugin-components/settings';
import '@hana/plugin-components/settings.css';

export function AppPanel() {
  return (
    <SettingsPage>
      <SettingsSection title="Sync">
        <SettingRow label="Enabled" hint="Follows the current Hana theme." control={<Switch checked ariaLabel="Enable sync" onChange={() => {}} />} />
        <SaveButton status="idle" labels={{ idle: 'Save', saving: 'Saving', saved: 'Saved' }} onSavedFeedbackEnd={() => {}} />
      </SettingsSection>
    </SettingsPage>
  );
}
```

`HanaThemeProvider` has three modes:

- `inherit`: use host CSS variables when the WebView receives them, then fall back to Hana defaults from `styles.css`.
- `hana`: set one of Hana's named theme token groups, such as `warm-paper` or `midnight`.
- `custom`: set only the tokens you provide. Missing tokens still fall back through host variables and SDK defaults.

`HanaThemeProvider` also accepts `density`, `tone`, and `accent` so a card can
match compact Chalkboard layouts, status-oriented panels, or App-specific
accent colors while keeping the rest of Hana's theme tokens intact.

First-batch components:

| Area | Components |
| --- | --- |
| Shell | `CardShell`, `TitleBar`, `Toolbar`, `ToolbarGroup`, `Section` |
| Settings subpath | `SettingsPage`, `SettingsSection`, `SettingsSurface`, `SettingRow`, `SettingsStack`, `Inline`, `Grid`, `Button`, `IconButton`, `TextInput`, `TextArea`, `Select`, `Toggle` / `Switch`, `NumberInput`, `SaveButton`, `VerificationButton`, `ListRow`, `DropdownMenu`, `ContextMenu`, `Tooltip` |
| Layout | `Stack`, `Inline`, `Grid` |
| Controls | `Button`, `IconButton`, `TextInput`, `Textarea`, `Select`, `Switch`, `Checkbox`, `SegmentedControl` |
| Feedback | `Badge`, `Callout`, `LoadingState`, `ErrorState`, `EmptyState` |
| Data | `List`, `DataTable` |
| Host action presentation | `ResourceActionPanel` |

`ResourceActionPanel` is presentation only. Wire it to `hana.resources.open()`,
`hana.resources.pick()`, or route-backed App logic from `@hana/plugin-sdk` so
host capability checks and slot policy stay in the SDK/host layer.

The root entry exposes stable `hana-plugin-*` classes for small local refinements. The settings subpath uses its public props and theme variables; its generated CSS module selectors are private.

Import settings controls only from `@hana/plugin-components/settings` together with
`@hana/plugin-components/settings.css`. Use them for Hana/App settings and management
pages, not for an embedded product's own frontend. `SettingsPage` is opt-in and owns the
32px settings geometry; `SettingsSection` owns its card-external heading and continuous
surface. `SaveButton` is visual feedback for explicit saves only: the caller owns the
draft and error, clears success through the callback, and preserves the draft on failure.
The settings subpath is self-contained apart from React and React DOM. It does not expose
desktop source paths, CSS module selectors, WindowSurface contexts, or Ant internals.

The companion settings CSS includes host-owned baseline typography, spacing, radii and toggle rules, generated from the same stylesheet as the desktop. Its base reset is scoped to `SettingsPage`. Load this CSS before applying host theme variables. The Hana settings container supplies outer page gutters; do not duplicate those gutters inside the App.
